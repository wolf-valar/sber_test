Openvpn client role

=========

OpenVPN Client install & configure role. 

Requirements
------------
 Destanation host os: Ubuntu 16.04
Role Variables
--------------
Vars must contains server and clients params:
 server:
  ip: [XX.XX.XX.XX]
  port: [XXXX]
  proto: [udp|tcp]
  ca: |
    -----BEGIN CERTIFICATE-----
    [XXXXXXXXXXXXXXXXXXXXXXXXX......]
    -----END CERTIFICATE-----
  tls: |
    #
    # 2048 bit OpenVPN static key
    #
    -----BEGIN OpenVPN Static key V1-----
    [XXXXXXXXXXXXXXXXXXXXXXXXX......]
    -----END OpenVPN Static key V1-----
  client:
    cert: |
      -----BEGIN CERTIFICATE-----
      [XXXXXXXXXXXXXXXXXXXXXXXXX......]
      -----END CERTIFICATE-----
    key: |
      -----BEGIN PRIVATE KEY-----
      [XXXXXXXXXXXXXXXXXXXXXXXXX......]
      -----END PRIVATE KEY-----


Dependencies
------------
No dependencies

Example Playbook
----------------

  ---
  - name: install ovpn
    hosts: ovpn
    become: yes
    roles:
     - openvpn_client

License
-------
MIT


Author Information
------------------

Schelokov Andrey 2019. holokov@yandex.ru
